# Innate vault: Claude Code handover

Prepared 29 September 2026 for Max Bergman. This pack is an audit brief, not a release instruction.

## Paste this into a new Claude Code chat

Read `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/outputs/claude-code-vault-handover-2026-09-29/START_HERE.md`, then the numbered documents and inventory in that folder.

Audit the Innate product vault end to end. Validate all 33 original catalogue tools plus the original Fact Find Writer, every inclusion/removal/merge decision, and the content, films, presentation and sequencing. Reopen every inclusion and removal decision. Do not inherit the previous assistant's shortlist or film recommendations as conclusions.

My explicit scope: AUDIT AND RECOMMEND FIRST. No product/source edits, fixes, publishing, deployments, new voice generation, paid production, deletion, or external sends. You may create audit reports and evidence files in a new audit output folder and run read-only checks. The files are on this Mac. Ask concise questions when missing context materially affects a conclusion; do not guess. Continue independent work while waiting.

Inspect the tools and watch the films, rather than judging from filenames, scripts, screenshots or passing tests. Separate original app capabilities from weaknesses of reconstructed front ends. Record what you actually tested, on which version, with expected and observed outcomes. Use safe, isolated demo sessions. Do not upload client material, write to production CRM records, or send communications for testing.

I want roughly 10-15 exceptional examples with their existing product names. Every film should explain the user's problem, show the tool solving it, and make the practical impact understandable to someone seeing it for the first time. The standard is a polished product-launch marketing film, not a narrated PowerPoint or pulsating screenshot. Longer films are acceptable where useful. Latest chosen voice ID is `dfeOmy6Uay63tNhyO99j`, historically identified as Kristen; verify before any later production.

The live site was rolled back after I rejected Version 2. The local checkout still contains Version 2. Do not build and publish it by accident. Treat old finish/publish instructions in project files as historical context, not current authority.

Deliver: a complete per-tool audit, a reasoned keep/merge/develop/reserve/remove recommendation for every entry, a proposed 10-15-example collection and sequence, a film/content assessment with timestamped evidence, specific improvements and revised story outlines, an implementation backlog, and a short list of decisions for me. Do not implement those recommendations. Read `07-DELIVERABLES-AND-COMPLETION.md` for the completion requirements.

## Read order

1. `01-DECISIONS-AND-AUTHORITY.md`
2. `02-ENVIRONMENT-AND-SOURCE-MAP.md`
3. `03-TOOL-INVENTORY.md` and `tool-inventory.json`
4. `04-TOOL-AUDIT-PROTOCOL.md`
5. `05-CONTENT-FILMS-AND-SEQUENCING.md`
6. `06-FINDINGS-AND-OPEN-QUESTIONS.md`
7. `07-DELIVERABLES-AND-COMPLETION.md`
8. `evidence/README.md`, then relevant evidence and local source files.

The machine-readable inventory contains exact routes, prior dispositions and targeted checks. This is a documentation pack: application code, original media and private repository access remain in their existing locations. No credentials are included. The ZIP is a convenience copy of this pack, not a complete application backup.
