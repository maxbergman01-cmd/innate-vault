# Environment and source map

Workspace: `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders`
Application checkout: `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/outputs/innate-vault`
Pack: `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/outputs/claude-code-vault-handover-2026-09-29`
Node observed: v20.11.1. Application working tree was clean at pack creation.

## Release boundary

- Public site: https://innate-product-vault.maxbergman01.chatgpt.site/#case-studies
- Original recovered site: https://innate-ai-website-review.vercel.app/#case-studies
- Local HEAD, verified: `fdd7d9d5de2d1d86302965542acc0feaa35a3c03` (rejected Version 2).
- Prior source commit: `5a08d778b057d4ea244f69647973abb3f347af7e` (Version 1).
- Recorded Sites project: `appgprj_6abacbe9b3f88191b22a76565448ce2d`.
- Recorded restored version: `appgprj_6abacbe9b3f88191b22a76565448ce2d~appgver_5fcd29ee0888819186a35a979e9c9db6`.
- Recorded rollback deployment: `appgdep_6abb8ed19d3881919dcc7787bdf9fc04`.
- Rejected version: `appgprj_6abacbe9b3f88191b22a76565448ce2d~appgver_9c0bf170940c8191a5cc750d75f31e80`.

Deployment IDs are recorded historical evidence, not a fresh hosting-status query. Recheck the live site independently. Fresh published-proposal inspection reproduced the old approval defect. Do not equate local files with live behaviour.

## Safe audit operations

Read source, use `git status`, `git log`, `git show` and `git diff`, inspect media, and run `npm test` in the application directory. Running `npm start` serves existing `public` files on 127.0.0.1:4173; check whether the port is occupied first and do not kill someone else's process. The previous preview had become unreachable. Local preview shows local Version 2, not the restored live site.

Do not run `npm run build` casually: it overwrites public files and replicated demo bundles. Do not checkout, reset, clean, install dependencies or alter the source under an audit-only remit. If a rebuilt comparison is required, explain the need and ask before changing the working tree. Do not run any render/finalise/implement/deploy script during this audit.

## Source map, relative to the application checkout

| Location | Meaning |
| --- | --- |
| src/catalog.js | 33 entries, original links, reconstructed overrides, historical claims and testimonials. Claims are not independently substantiated by their presence here. |
| src/workflows.js | Historical six workflow groups and route selection. Not the final 13-tool plan. |
| src/index.html, src/app.js, src/styles.css, src/stories.js | Local rejected website presentation; compare with prior commit and live. |
| src/experiences/apps.js | Five reconstructed apps: client, trends, PLM, sales, LinkedIn. |
| src/demo-logic.js | Local arithmetic and state rules for cashflow, annual, listing and action validation. |
| src/demos/real-estate.js, src/demos/wealth.js | Readable recovered bundles with framework code before application code. Not original component repositories. |
| public/demos/ | Recovered standalone and collection applications. Some are bundled/minified. |
| src/films/catalog.js | 33 legacy film entries, routes, durations, media and voice metadata. |
| src/films/, public/films/ | Player pages, media, captions and rejected story variants. |
| tests/ | Focused logic and historical inventory/media checks. Not exhaustive runtime or film-quality tests. |
| server.mjs | Local route fallbacks and media range responses; POST explicitly unavailable. |
| build.mjs, build-experiences.mjs | Mutating build operations, not required for initial audit. |

## Production and research outside the application

- `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json`: 33 historical scripts/capture actions; per-product folders contain footage, audio and timelines.
- `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/client-film/`: earlier Client Intelligence pilot production.
- `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/vault-rebuild/`: rejected five-film build, original narration and captures, later unapproved drafts and live proposal evidence.
- `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/research_notes/Innate vault strategy and storytelling/`: source audit, film research and professional-services benchmarks. Read their stated limits and superseded recommendations.
- `/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/reports/Innate vault strategy and storytelling.md`: historical synthesis, not current authority.
- `/Users/max/Downloads/Innate-device-handover-2026-09-25/`: earlier mixed OS/vault continuity materials. Only inspect vault-relevant sections; do not resume unrelated Notion, onboarding or sales-collateral tasks.
- `/Users/max/.codex/attachments/c8b9aa36-1318-4d19-bef7-c61d61fa684e/Pasted text.txt`: earlier continuity context, not new permission.

## Original Fact Find Writer

- Repository: https://github.com/maxbergman01-cmd/innate-rfp
- Application: https://rfp-partners-workspace.onrender.com/
- Review specification: https://github.com/maxbergman01-cmd/innate-rfp/blob/main/docs/04-review.md
- Additional docs worth examining: docs/03-writer-runs.md, docs/wiring-matrix.md, docs/extraction-reliability-spec.md, docs/per-field-confidence-calibration.md, docs/integration-release-boundary-2026-09-14.md.

Previously accessed using the signed-in Codex browser. Connector returned 404 despite browser access. A Claude Code session may not share that browser authentication. Test access; ask for the minimum missing access if blocked. Do not copy cookies, tokens or saved passwords. No local clone is included or asserted to exist. No end-to-end production extraction/write was run in this assessment.

## Baseline recorded during pack creation

`npm test`: 17 passed, 0 failed on local HEAD. No build run. Several tests explicitly require 33 films, sub-minute legacy media and the rejected five-story presentation. A passing result therefore confirms those narrow assertions only. Catalogue snapshot contains 33 unique entries; adding original Fact Find Writer produces 34 audit rows.
