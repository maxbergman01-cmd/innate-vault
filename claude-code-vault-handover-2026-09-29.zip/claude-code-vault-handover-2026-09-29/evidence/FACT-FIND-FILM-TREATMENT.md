# Fact Find Writer: working film treatment

Draft for content and production review. Target approximately 85-100 seconds, subject to a natural read and recorded product timing. This is a shot plan, not a completed film or a claim of tested end-to-end functionality.

## Central story

An adviser already has the information, but it is scattered across conversations and documents. Fact Find Writer turns it into proposed structured client information, makes disagreements visible, and gives the adviser control over what reaches Intelliflo.

The emotional transition is from reconstructing the client's position to making an informed review. The key reveal is a source-backed proposed change beside the current record, followed by a controlled write result. Avoid a generic AI sparkle, confidence gauge montage or a tour of every input type.

## Sequence and working narration

| Approximate time | Picture and product action | Working narration |
| --- | --- | --- |
| 0-12s | One coherent example household. Open a meeting transcript and an existing fact-find document. Focus on the same detail appearing differently. Keep enough surrounding text to make the evidence understandable. | “A client meeting ends. The work of updating their record begins. The information is there, across the conversation, their documents and the existing fact find. But it still needs to be brought together and checked.” |
| 12-24s | Reveal the real Fact Find Writer intake. Show the two sources attached to one client run. Start extraction. Use an editorial cut if processing takes longer; do not fabricate instant processing. | “Fact Find Writer brings those sources into one review, turning unstructured information into proposed updates to the client's record.” |
| 24-43s | Move into the actual review interface. Show proposed information beside the current record. Hold on one understandable difference, with its supporting source visible. | “The adviser can see what has changed, compare it with what is already held, and examine the evidence behind the proposed update.” |
| 43-61s | Review two contrasting items: accept a supported change, then leave an ambiguous item pending. If correction is necessary, show edit followed by explicit acceptance. Capture the resulting state rather than merely the cursor pressing a button. | “A supported change can be accepted. A detail that needs clarification can stay pending. And where a correction is needed, the adviser can edit and approve it before it moves forward.” |
| 61-80s | Show the actual commit summary and confirmation for the approved changes. Follow through to the recorded result. Only use a safe test client or equivalent controlled environment for capture. If a record is held or fails, show its true result. | “Approved changes move through a final confirmation before writing to Intelliflo. The result shows what was written and what still needs attention.” |
| 80-95s | Finish on the resulting client information and remaining review work, framed legibly. End with the existing product name and a restrained Innate identity. | “The result is a structured client record built from the available evidence, with the adviser in control of the changes. Fact Find Writer.” |

## Production direction

- Record genuine product interaction in a consistent desktop viewport. Use a clean, internally consistent example throughout.
- Establish the whole application once, then compose close shots of the exact source, difference, decision and output being discussed. Do not shrink an entire interface into an unreadable decorative frame.
- Cut between distinct states and actions. Movement should guide attention or connect source to result. No idle screenshot pulsing.
- Let the viewer read the key discrepancy before the narration resolves it. Synchronise captions with the spoken line, not a dense paragraph on top of the interface.
- Use the selected Kristen voice only after the wording is approved. Judge a short natural delivery sample before generating the complete track. Preserve clean audio through the edit and export.
- Music, if used, sits beneath intelligible speech. No dramatic sound effect on every interaction.
- Capture the real UI first, then build the edit around what it actually demonstrates. Do not render a motion mock-up as evidence of working functionality.

## Required before capture

The intake and repository review/commit documentation have been inspected. Extraction, review and Intelliflo writeback have not been freshly exercised end to end in this assessment. Confirm a safe capture environment and prepare suitable example sources, then validate the complete journey. Do not write to a real client's record for footage.

Check that the actual source display supports the proposed shot. If it does not, revise the shot rather than invent a source panel. Verify the exact result presentation and adjust the final narration accordingly. No numerical time-saving or error-reduction claims are included.

## Scope boundary

This film covers Fact Find Writer, not the separate Action Tracker or reconstructed Annual Review Pack Studio. No new site copy, live deployment, voice generation or video replacement accompanies this treatment.
