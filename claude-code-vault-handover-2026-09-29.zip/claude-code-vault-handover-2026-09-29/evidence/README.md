# Evidence copies and caution

These are copied snapshots, not current instructions. Original source paths are in FILE-MANIFEST.json. Relative links inside copied historical documents may refer to their original location; consult the original file for those links. Do not run finish/publish instructions embedded in historical records.

- research-tool-evidence-audit.md: earlier 33-tool source audit, no complete fresh runtime audit. Earlier all-synthetic assumption and smaller shortlist are superseded.
- research-film-storytelling.md: reference research and editorial analysis. Intelliflo was only partially visually sampled; do not claim full viewing.
- research-vault-benchmarks.md: mostly text-level observations, not demonstrated conversion performance. Old titles/count/page-copy recommendations are superseded.
- PRODUCT-ACCEPTANCE-DRAFT.md: proposed product journeys, not proof of implementation. Its preserve-removals stance is superseded by reopening all decisions.
- FACT-FIND-FILM-TREATMENT.md and THREE-PRODUCT-FILM-DRAFTS.md: unapproved narration/shot proposals, not finished films.
- PROPOSAL-LIVE-VALIDATION.md and screenshot: fresh29 September published-demo evidence, no send/approval performed.
- HISTORICAL-IMPLEMENTATION-STATUS.md: rollback notice controls. The following Version 2-live and publish instructions are stale.
- catalogue-snapshot.json: local 33-entry inventory and film metadata. Ready/duration/voice fields are historical metadata, not verification of content or live media.

Fresh pack-creation baseline: local application clean at fdd7d9d; npm test: 17 passed / 0 failed; no build or source edits. Audit instructions in the numbered documents supersede suggestions copied here.
