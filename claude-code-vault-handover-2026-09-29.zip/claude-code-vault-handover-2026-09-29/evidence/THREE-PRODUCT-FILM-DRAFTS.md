# Three product film drafts

29 September 2026. Editorial drafts grounded in recovered source inspection. Not approved scripts, completed films or fresh runtime verification. No live changes. Each film should run as long as its natural delivery and readable product action require, provisionally 70-95 seconds.

These scripts deliberately do not claim unverified AI processing. Insert a specific AI mechanism only after its original implementation is confirmed. Production must capture consequential product action, not illustrate narration with a moving screenshot.

## Proposal and Quote Agent

### Narrative

Winning the work is only half the job. The promise also needs to make commercial sense.

A proposal brings together the client's requirements, the team's scope and the price. Change one of them, and the others need another look.

Proposal and Quote Agent keeps those decisions together.

Here, a discount has taken the offer beyond the team's approval threshold. Open the price build-up and the consequence is visible: the client's saving, the delivery cost and the margin left on the work.

Revise the discount, and the figures change together. Check the deliverables, dependencies and exclusions alongside the price, so the team can see exactly what it is committing to.

The resulting proposal carries that scope and commercial position into one client-facing document.

An offer the client can understand. A commitment the business has examined.

Proposal and Quote Agent.

### Shot sequence

1. Start inside an actual proposal: the client's price is prominent. Reveal the associated delivery cost and margin. The opening contrast is commercial, not decorative.
2. Establish the application around that record. Show the approval condition on the same opportunity.
3. Inspect the price build-up. Frame the discount, total and margin together at a readable scale.
4. Make one deliberate discount revision. Hold on the changed figures long enough to understand the relationship. Verify the approval state also reflects the current offer before capturing this sequence.
5. Move to the same proposal's scope. Focus on one deliverable and a corresponding dependency or exclusion. Do not flick through every tab.
6. Open the client-facing preview, preserving the same opportunity, scope and totals. Finish on the useful document, then the product name.

### Before recording

Verify all numerical states and rounding from a clean session. The previous local approval fix is not evidence that the restored live version behaves identically. Do not simulate an email being sent or claim automatic ingestion of a new brief without verifying those capabilities. Exact screen values belong in the footage, not the voice track, so narration remains natural.

## Availability & Listing Inbox

### Narrative

A property record is only useful if the information behind it is current.

An updated schedule arrives. The floor area has changed. But two tabs give different availability dates. Updating everything would turn a contradiction into something that looks certain. Leaving everything untouched would keep the record out of date.

Availability and Listing Inbox separates the changes the team can use from the questions it still needs to resolve.

Compare the incoming information with the existing listing. Accept the supported update and see it carried into the property record. Keep the conflicting date out of the update, with the reason still visible.

Then prepare the clarification needed to complete the picture.

The next colleague sees the latest supported information and knows what still needs checking before it reaches a client.

Availability and Listing Inbox.

### Shot sequence

1. Open the actual update schedule scenario whose evidence describes two conflicting dates. Establish the property and source once.
2. Show the existing area of 6,100 sq ft beside the proposed 6,320 sq ft. Frame the evidence and change together.
3. Shift attention to the conflicting availability field. Use the actual application warning. No invented error dialogue or exaggerated alert animation.
4. Accept the supported area update. Show the resulting listing value change while the availability field remains unresolved.
5. Show the prepared clarification, if the runtime supports it for this scenario, and keep the wording specific to the dates.
6. Return to the record and its remaining question. Finish with continuity for the colleague who next uses the listing, rather than a generic success badge.

### Before recording

Check the entire chosen document scenario at runtime, including the clarification output. Do not mix an area update from one property with a rent change from another. Accepted fields must survive the sequence; held fields must not be silently applied. Do not claim automatic publication to a property portal.

## Annual Review Pack Studio

### Narrative

An annual review should begin with the client's position. Preparing for it often begins with finding out which information can still be relied on.

Statements, household records and previous valuations arrive at different times. A complete-looking pack can still contain an incomplete picture.

Annual Review Pack Studio brings the sources and the review position together.

The team can see what is current, what needs clarification and what should stay out of this pack. Those decisions affect the figures, not just a checklist.

Exclude the mortgage statement, and the pack no longer presents a complete net-worth figure. Add the context the adviser needs, with the outstanding evidence kept visible.

Then preview the pack: the reviewed information, the financial position it supports and the questions still to resolve.

The adviser begins with a clearer basis for the conversation, and a precise view of the preparation still outstanding.

Annual Review Pack Studio.

### Shot sequence

1. Establish one household and its actual source register. Show the different evidence statuses without inventing new document dates.
2. Open a source needing clarification, such as the pension evidence with the missing exit-penalty field. Briefly reveal the specific gap.
3. Establish the current financial position. Exclude the mortgage source and show the resulting incomplete position. This is a controlled demonstration of an exclusion, not a claim that this source was originally invalid.
4. Add a useful adviser note. Show where that note appears in the resulting pack.
5. Preview the pack. Frame the financial position and remaining gaps in readable successive shots, retaining the same source decisions.
6. End on the prepared meeting material. Do not suggest a completed advice recommendation or CRM writeback.

### Before recording

Verify source decisions, figures and notes propagate through the preview and download. Confirm the incomplete-position wording is understandable without narration. Keep this distinct from Fact Find Writer: this product prepares meeting material; Fact Find Writer reviews proposed client-record changes and controls writeback.

## Production standard for all three

Capture real product states before assembling the edit. Each shot must explain a business consequence or reveal the mechanism. Use consistent framing, considered typography, controlled transitions and clean speech. Reserve full-screen text for a brief opening or closing where it earns its place. Do not build the films as a sequence of narrated title slides.

The application footage must remain legible on the intended watch page. Review the finished pilot with sound, without sound and at normal playback speed before commissioning the remaining films. Music and motion cannot compensate for an unclear product story.
