# ROLLED BACK AT USER REQUEST

Version 1 was restored live on 29 September 2026. Deployment appgdep_6abb8ed19d3881919dcc7787bdf9fc04 succeeded. The user rejected the slideshow-style films as below the required marketing quality. Do not republish version 2 or the current local rebuild without a new direction and approval. Local files retain the rejected rebuild for reference only.

# Vault rebuild status

The five-tool business-problem vault and five Problem / Solution / Impact scripts are implemented locally. Final narrated films are complete and verified. Version 2 is live at https://innate-product-vault.maxbergman01.chatgpt.site/#case-studies.

Selected tools: Proposal and Quote, Invoice Operations, Annual Review, Listing Inbox, Drawing-to-Quote. Other assets remain preserved.

## Completed

- Business-problem navigation and five-card showcase, with industry labels and filtering.
- Individual story pages: problem, solution, impact, mechanism, tool link, contextual enquiry, script transcript.
- Shared main-site styling, actual tool thumbnails, mobile layout checked at 390px with no horizontal overflow.
- Removed unsupported case-study outcomes and testimonial carousel from public homepage; removed old case-result structured metadata.
- Five scripts in stories.json and narration.txt. Latest selected voice: dfeOmy6Uay63tNhyO99j.
- Fresh UI captures for all five tool stories, 4 per tool. Six-scene visual masters and storyboards prepared by render-stories.py.
- Proposal discount change now recalculates the approval state. Approval display and approve action derive the approver from current pricing rules.
- All 17 tests pass, including the publication gate requiring each selected story to have a new film and caption file.

## Runtime evidence

- Proposal: 12% discount / £44,176 / 30% margin requires James Attwood. At 5%, £47,690 / 35% margin, stage becomes Pricing, approval cleared.
- Invoice: £14,820 bank-detail exception inspected; escalation removes it from the open queue and records the session decision. Full page navigation resets local example state.
- Annual: missing pension exit-penalty detail remains visible. Adviser note appears in the generated pack alongside sources and totals.
- Listing: four supported field decisions applied. Business rates remains unaccepted and confirmation request is separately prepared.
- Quote: length 12.17 to 13 updates scaffold 186.28 to 192.92 LM and quote £4,414.84 to £4,572.20. Internal birdcage dimensions remain separate.

## Narration recovered

ElevenLabs generated the five-script batch with Kristen on 29 September 2026. Downloaded original MP3 is retained as narration.mp3. Automatic word alignment matches 98.3–100% of each script. Final timed visual masters are rendering; finalise-films.py will add audio and activate the new film routes. No further voice generation is required.

## Finish sequence

1. Complete timed visual rendering, then finalise-films.py.
2. Fully decode all five final videos, check audio peaks/captions, run the 17 website tests and browser playback checks.
3. Publish the existing Sites project using its normal source workflow and native save/deploy tools.

## Final verification

All five 1920×1080 exports fully decode. AAC narration peaks range from -1.1 to -0.5 dB. Captions have valid ordered boundaries; script alignment is 98.3–100%. Browser playback of the proposal film advances correctly. Desktop/mobile layout and underlying tool actions were checked before publication.

## Published

Native deployment succeeded on 29 September 2026. Version 2; source commit fdd7d9d5de2d1d86302965542acc0feaa35a3c03. Deployment appgdep_6abb8dd0d9a48191a8fc8a563cc39a04.
