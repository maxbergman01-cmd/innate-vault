# Proposal film readiness: published version

29 September 2026. Fresh browser validation on the published vault's recovered proposal demo. No proposal was sent, no approval was submitted and no deployment was changed. Only temporary demo-session input was changed.

URL: https://innate-product-vault.maxbergman01.chatgpt.site/demos/proposal-quote-agent/

## Results

| Check | Observed result |
| --- | --- |
| Open the Loxley Foods pricing exception | Initial 12% discount, £50,200 rate-card subtotal, £44,176 total and displayed 30% margin. |
| Initial approval consistency | Margin warning requires James Attwood, while send control says approval from Elena Wray. The interface gives conflicting authority cues. No send was attempted. |
| Change discount to 5% | Total becomes £47,690 and displayed margin becomes 35%. Numerical changes propagate immediately. |
| Approval after the change | Still shows Awaiting approval and says the 5% discount is above the 10% delegation. This is false and contradicts the current pricing. |
| Preview after the change | Preview correctly shows 5%, £2,510 discount and £47,690 total, with the same proposal scope and exclusions. |

## Film decision

The price-to-preview relationship is suitable material, but the published journey is not ready to record as a coherent approval story. Fix and verify approval routing, stage and explanatory copy first. Do not hide the contradiction through selective framing.

The local recovered bundle already contains an earlier setDiscount correction that recalculates the approver and clears the approval stage where appropriate. That is source evidence only in this check, not fresh runtime verification of the local fix. It is contained within the previously rejected Version 2 checkout, so deploying that checkout wholesale would restore rejected presentation changes. Preserve the rollback boundary and release any correction separately when publication is authorised.

Screenshot: proposal-live-approval-inconsistency.png

## Required correction acceptance checks

- The approver shown in the margin explanation and approval action must follow the same current rules.
- A discount within delegation with sufficient margin must not retain an obsolete discount approval reason.
- Raising the discount again must recalculate the required authority rather than reuse the previous cleared state.
- Preview must remain consistent with the current scope and price.
- Any simulated send must enforce the same decision as the visible interface. This was not tested in this pass.
