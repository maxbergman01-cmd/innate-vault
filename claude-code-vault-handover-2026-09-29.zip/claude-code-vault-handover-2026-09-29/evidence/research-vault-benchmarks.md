# Professional-services vault presentation and curation

## What patterns do relevant professional-services firms actually use?

### Takeaway
The useful pattern is a selected layer of business stories with deeper evidence behind each, not a uniform catalogue of software names. This is a descriptive benchmark, not conversion research: none of the inspected pages supplies an experiment proving its own layout performs best.

### Cited Findings
Accessed 29 September 2026 using live web page extraction. Seven firms examined. Text structure, links and exposed controls were inspected; this was not a pixel-level, mobile or interactive filter usability audit. Search crawl dates vary. Repeated carousel content in extracted text was not counted as separate cases.

| Firm / relevance | Observed landing information | Taxonomy and curation | CTA / lesson / limitation |
|---|---|---|---|
| [Faculty Impact](https://faculty.ai/en-gb/impact), applied-AI implementation specialist | Featured cards pair outcome/action headlines with short explanations and clients. Three unique featured stories are Tide, hospital admissions and DRIFT energy routing. | Featured layer followed by searchable results; industry and service labels visible on results. Page reports 20 results and additional loading. | Read more opens case content; separate contact CTA. Strong reference for editorial selection plus library. Full filter options not exposed in fetched text. |
| [Baringa Client Stories](https://www.baringa.com/en/impact/case-studies/), management consultancy | Cards use industry, problem/outcome headline, explanatory sentence and Read more. Some descriptions carry quantified outcomes, others describe the business challenge. | Prominent selected stories before a larger list. Independent Industry and Capabilities filters; 12 of 150 displayed. | Problem framing and industry identification coexist. Archive scale justifies filters; it does not establish that Innate needs 150 items or multiple filter dimensions. |
| [Thoughtworks Clients](https://www.thoughtworks.com/clients), technology consultancy | Industry sections introduce the sector's needs and link a client story. Named clients and capability labels appear. | Industry-led exploration followed by topic choices such as AI/ML, platforms and customer experience. | Read this client story. Good evidence for two entry paths, sector and capability, but not for treating every UI tool as a separate case. |
| [QuantumBlack Case Studies](https://www.mckinsey.com/capabilities/quantumblack/case-studies), strategy/applied AI | Story headlines foreground organizational change, customers or operational work, with named organizations such as KPN, Entel and Toshiba Tec. | Curated story list in the accessible extract; no filter controls visible in this extraction. | Connect with us plus story links. Cannot conclude no filters exist elsewhere or on a different device. |
| [BCG AI](https://www.bcg.com/capabilities/artificial-intelligence), large consultancy / BCG X | Selected client impact cards combine client/business action, brief narrative and prominent metrics, e.g. Reckitt efficiency and Rio Tinto productivity. | Client work presented separately from enterprise AI product library. | Learn more / broader client work. Distinguishing evidence about client change from reusable product inventory is especially useful for Innate. Metrics are publisher claims, not independently verified here. |
| [Satalia Our Work](https://satalia.com/our-work/), AI optimization specialist | Intro leads with client outcomes, including delivery distance/capacity and customer satisfaction. | Explicit Featured case study section then Case studies with Product/service filter. | Case stories and a separate Videos resource destination. Dynamic card contents were missing in extracted page, so only exposed hierarchy/filter is established. |
| [HatchWorks Our Work](https://hatchworks.com/our-work/), AI implementation peer | Titles describe movement from a business bottleneck to a capability or benefit. Named/anonymous clients supported by separate attributed testimonials. | Initial 12 story links plus Load More. Homepage has selected work linking to broader library. | Learn more and Start a Conversation. Tools have a separate navigation category. This is a closer commercial reference than copying an enterprise consultancy's entire information architecture. |

Additional counterexample: [WeAreBrain Work](https://wearebrain.com/work/) exposes filters for technology, solution, engagement type and industry. This establishes that highly technical filtering exists, not that it helps an executive buyer. Its card content was not captured reliably, so excluded from the seven-firm core comparison.

### Inferences
- Recommended starting architecture: one curated public portfolio, with three spotlight stories and a total of roughly six to eight genuinely distinct, complete examples. This count is an editorial production recommendation responding to the user's quality-over-volume instruction, not a research-backed optimum or a quota to fill.
- Do not display weak work publicly merely to fill an archive. Preserve it internally for improvement or tailored sales use. Large consultancies have archives because they have many evidenced engagements; that is not a reason to copy their volume.
- Use buyer-recognizable workflow language for titles and outcomes for the supporting line. A generic outcome such as saving time is too broad to discriminate between examples; a software name alone asks the reader to infer relevance.
- Primary taxonomy remains dependent on target buyers. If Innate is prioritizing a few sectors, lead with those sectors and a few relevant stories per sector. If selling similar operational problems across sectors, lead with workflows and show industry as a secondary tag. Both patterns are present; no source proves one universally superior.
- For six to eight items, test whether any filter is necessary. A short, curated page with clearly differentiated cards may be simpler. Do not add technical categories, multi-select controls and search merely because large libraries use them.

### Gaps
- Priority buyers, sector focus, sales objective and traffic source are pending. Cannot responsibly choose the final taxonomy or shortlist without them.
- No benchmark supplied measured conversion effects for featuring three cases, a specific grid size, video-first CTAs, or reducing catalogue size.
- Visual hierarchy and mobile behavior need a separate rendered-page review before using these pages as visual references. This research establishes content/information architecture only.

## What makes the case narrative credible and useful?

### Takeaway
The strongest inspected narratives connect a named user and operational constraint to a specific intervention, then bound the impact claim. Problem, Solution, Impact works when each link is concrete and causally intelligible; headings alone do not create evidence.

### Cited Findings
- [Faculty's Dstl story](https://faculty.ai/en-gb/ourwork/dstl) uses Background, Solution and Impact. It explains analysts' slow article discovery/review, a centralized platform and recommendation algorithms informed by prior activity, then reports hundreds of analyst hours saved and a client-attributed statement. It differentiates what the AI recommends from the broader collaboration platform. The extract includes a media-player marker and PDF download, but actual film content was not watched.
- [HatchWorks email automation](https://hatchworks.com/case-studies/ai-powered-email-automation-frees-sales-team-to-focus-on-high-value-orders/) identifies a seven-person sales team overwhelmed by routine incoming mail. It explains message classification, ERP retrieval, Outlook drafts, exceptions and review. It reports 47% coverage among emails needing replies, not all mail. Important inconsistency: body says up to 70% send-ready responses; Key Stats calls this response accuracy. Treat these as different metrics and do not repeat an ambiguous label as verified accuracy. No independent validation or measurement period was visible.
- [HatchWorks AVA](https://hatchworks.com/case-studies/ai-virtual-assistant-aircraft-maintenance/) connects inaccessible maintenance history and mechanic capacity pressure to an assistant retrieving cited history and structured data. It names the client, includes the president's attribution, and labels 85%+ NPS as a target while labeling about 30% fewer recurring actuator issues a pilot example. This is useful evidence-type differentiation; it does not prove a universal 30% reduction.
- [Baringa government AI adoption](https://www.baringa.com/en/impact/case-studies/delivering-millions-in-productivity-gains-through-ai-adoption/), dated 16 March 2026, describes fragmented experimentation, prioritization and rollout work, then identifies up to £40m as potential productivity benefits. The attractive headline must not cause a writer to turn potential into realized savings.
- [QuantumBlack AAA](https://www.mckinsey.com/capabilities/quantumblack/how-we-help-clients/modernizing-a-100-year-old-business-model-with-ai), dated 18 February 2026, presents the CEO's interview and business context. Faster resolution and lower cost are framed as what the system may help achieve, and tenfold capacity as a goal. These are not equivalent to measured post-deployment results.

### Inferences
- Each Innate candidate needs a fact sheet before a film script: intended user; triggering situation; current workflow; exact friction; consequence; input; transformation; output; human decision; AI role; deployment status; evidence and its owner; permitted client disclosure.
- The first public card should be readable without watching: buyer/industry tag, plain-language problem or change headline, one-sentence explanation and one appropriately qualified proof line. Do not make a film the sole source of meaning.
- A case page can carry a short film plus the same Problem, Solution, Impact in text, with actual screenshots and clear evidence context. This supports silent readers and lets buyers inspect a claim instead of accepting a narrated assertion.
- Define three evidence states internally: measured client result; observed pilot result; expected benefit to validate. Public language must preserve the distinction. A reconstructed example cannot acquire real-client impact merely because its interface looks complete.
- Explain AI only at the point where it changes the workflow: extracting facts from documents, ranking relevant records, drafting an evidence-linked response, flagging exceptions. Distinguish model inference from deterministic calculations, data fetching and workflow routing. Do not bolt an AI claim onto an ordinary dashboard.
- Present one meaningful end-to-end workflow rather than a montage of four unrelated screens. Show the painful input, the system action, the reviewed output and the practical consequence. If a step does not exist, it needs implementation or removal from the claim, not cosmetic narration.
- These recommendations are editorial judgments grounded in the observed narratives, not causal conversion findings.

### Gaps
- Innate's actual measured results, client permission, live deployment status and underlying AI mechanisms have not been verified in this research stream.
- Peer publishers' claims were not independently audited. Their structural clarity is reusable; their numerical outcomes are not transferable to Innate.
- Whether the current Innate tools expose sufficient functional substance requires the separate code/product audit. A film cannot substitute for that evidence.

## How should Innate curate and connect films, tools and sales conversations?

### Takeaway
Curate around buyer value and demonstrable substance, with a film providing the first explanation and the tool providing optional depth. The shortlist should be evidence-gated; ranking before the buyer and proof inputs are known would manufacture certainty.

### Cited Findings
- Faculty separates a featured story layer from its searchable wider work, while Baringa separates selected stories from industry/capability-filtered breadth. [Faculty](https://faculty.ai/en-gb/impact); [Baringa](https://www.baringa.com/en/impact/case-studies/).
- BCG distinguishes client impact from products; HatchWorks distinguishes case work from tools. This is evidence that case histories and reusable tools can have different navigational roles, not proof that any one CTA order converts better. [BCG](https://www.bcg.com/capabilities/artificial-intelligence); [HatchWorks](https://hatchworks.com/our-work/).
- Satalia exposes separate case-study and video resource destinations. Its extracted structure does not establish whether videos are embedded within every case. [Satalia](https://satalia.com/our-work/).

### Inferences
Proposed internal selection rubric, deliberately not numeric until buyer inputs arrive:

| Gate / criterion | Keep publicly only if | Action if weak |
|---|---|---|
| Buyer relevance | A priority buyer recognizes the situation and consequence | Reserve for a relevant campaign or remove from public shortlist |
| Functional substance | A visitor can see a complete transformation from input to useful output | Rebuild before filming |
| Truth of mechanism | Claimed AI and automation match the actual implementation or are clearly bounded illustrative capabilities | Correct copy and capability description |
| Evidence quality | Status and benefit claims can be supported at their stated level | Use qualitative benefits without invented results, or reserve privately |
| Differentiation | Example demonstrates a materially different pain, mechanism or commercial value | Merge overlapping tools into a single workflow story |
| Visual explainability | A first-time viewer can understand the key intervention in one short sequence | Simplify scenario or invest in an improved demonstration |
| Sales usefulness | It gives a credible reason for a qualified buyer to discuss their own workflow | Refocus on business situation rather than feature inventory |

Recommended page treatment, conditional on audit:
1. Lead with a buyer-relevant promise and three spotlight stories. Do not lead with the number of tools.
2. Show the remaining strong stories below, with one simple grouping if needed. Preserve all existing assets internally.
3. Each story opens a focused page or presentation containing the explanatory film, concise Problem/Solution/Impact text and evidence context. Primary initial action: Watch how it works, with duration. Secondary action after context: Explore the tool, only if usable. Commercial action: Discuss a similar workflow, linked to the example.
4. If an item is an illustrative product demonstration without client evidence, do not title it as a client success case. Neutral portfolio naming such as AI in action or Selected solutions avoids implying a measured engagement. Final name depends on what the retained items actually are.
5. Validate with first-time viewers from the target audience: after one viewing, can they identify user, problem, intervention, AI role and practical benefit? Measure this comprehension before polishing all films. Later evaluate qualified enquiries and relevant engagement, not just video plays.

The benchmark does not justify deleting a tool based on visual taste, nor keeping six near-duplicates solely to hit a target count. A stronger conceptual grouping may turn several modules into one convincing workflow example while retaining their underlying functionality.

### Gaps
- Need user's ranked target buyer/sector list, sales motion, strongest real engagements, client disclosure permissions, independently supportable results, and strategic tools to preserve.
- Need agreement whether first-wave scope is three flagship films followed by the remaining shortlisted items. This is a recommended quality-control sequence, not an assertion that the user has approved a reduced implementation scope.
- Actual final tool choices, final script claims and live-site changes should remain pending these answers and the product audit.
