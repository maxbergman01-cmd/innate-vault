# Product-film storytelling: Problem, Solution, Impact

Research date: 29 September 2026. Scope: official product narratives, primary video guidance, Innate scripts and implementation. No voices generated or products edited. Current films and working demos are synthetic examples, per the user's clarification. They can be professionally staged as realistic scenarios; they cannot be presented as documented client deployments or measured client outcomes.

## What should be learned from the reference and relevant B2B examples?

### Takeaway
Use one recognisable job and its consequence as the organising idea. Explain what changes in that job, show the transformation, and end on the practical result. A tour through buttons does not establish why the product deserves to exist.

### Cited Findings
- Intelliflo's Engagement Assistant page follows the adviser’s day: meeting capture and document intake; suggested client updates for review; linked client documents and report preparation. Its named adviser testimonial links lower administration to better preparation and more attentive conversations. These are vendor claims, not independently verified results or evidence transferable to Innate. [Official Engagement Assistant page](https://www.intelliflo.com/partners/integrated-partners/intelliflo-iq-engagement-assistant/)
- The user's exact reference is accessible as the embedded “Discover intelliflo IQ's Engagement Assistant” film, distinct from the introductory IQ film. Browser controls showed 2:10 duration versus 4:50 for the introduction. I started playback and visually inspected a frame at 0:45: a phone recording interface, waveform and a prominent benefit statement about capturing goals and income changes. The frame pairs a concrete interface with an explanation, rather than expecting the viewer to read a whole dashboard. [Reference page](https://www.intelliflo.com/software/artificial-intelligence/)
- Intelliflo's newer IQ page explicitly distinguishes the live Engagement assistant from future assistants, and explains the mechanism as transcription, extraction, suggested field updates and adviser sign-off. It contrasts native record updates with re-keying into a separate system. [IQ assistants](https://www.intelliflo.com/nextgen/iq-assistants/)
- Gong’s recorded sales-leader demo is framed around a specific management job: understand whether frontline managers are coaching the middle of the team. The page chapters move from coaching metrics to the coaching inbox, then actual call feedback and manager activity. This is a longer demonstration, not a 60-second format benchmark. [Gong sales-leader demo](https://www.gong.io/instant-demo/sales-leader)
- Harvey’s litigation/transactional demo description starts with workload and service pressure, then names tangible legal outputs: extracted facts, chronologies, first drafts, due-diligence issues and closing checklists. Its target workflows are specific to the audience rather than a general feature list. [Harvey demo](https://www.harvey.ai/resources/webinars/live-demo-harvey-for-litigation-and-transactional-teams)
- Dext’s practical bookkeeping demo describes document capture, extraction, review/correction, categorisation and reconciliation within existing accounting workflows. The description explicitly positions human review alongside automation. [Dext practical demo](https://info.dext.com/dext-smarter-bookkeeping-starts-here-ai-automation-you-can-trust-ty)
- CoCounsel’s product presentation describes source-grounded research, analysis and drafting; its examples include traceable document answers and attorney review of arguments and citations. This is useful as a mechanism-and-control reference, not proof that Innate can perform those functions. [CoCounsel Legal](https://legal.thomsonreuters.com/en/products/cocounsel-legal)
- Wistia distinguishes explainers (“why would I use it?”) from demonstrations (“what does it do and how?”), recommending a narrative and early product visibility. Its length guidance says duration depends on the goal and viewing context, rather than a universal best length. [Product-video guidance](https://wistia.com/blog/product-video-best-practices); [Length guidance](https://wistia.com/blog/optimal-video-length)

### Inferences
- **Editorial recommendation:** produce an explainer-demonstration hybrid. Establish pain in normal business language, then demonstrate one complete transformation. Combine the explanation and product evidence in the same shot.
- Business-problem-first titles suit a broad decision-maker audience: “Turn meeting notes into accountable follow-up”, not merely “Meeting Actions & Client Follow-up”. Keep the product name secondary.
- The benefit should close the loop opened by the pain. If the opening is dropped commitments, the ending must be named owners and visible deadlines, not an unrelated claim about productivity.
- These examples demonstrate credible presentation patterns. This research does **not** establish which visual format converts best or prove any resulting conversion uplift.

### Gaps
- I did not listen to or watch the entire Intelliflo film. Its settings exposed speed and quality but no caption/transcript option. Therefore the exact spoken script, opening sequence, pacing and soundtrack have not been evaluated. The 0:45 screenshot observation is only a visual sample.
- Gong, Harvey, Dext and CoCounsel observations are from official text/pages, not full audiovisual reviews. Do not claim all films were watched.
- No evidence here validates Intelliflo's savings percentage or another vendor's ROI. Do not repeat their numbers as Innate evidence.

## Why do the current Innate scripts undersell the tools, and what can they honestly claim?

### Takeaway
The problem is conceptual before it is stylistic: the scripts narrate review actions without establishing the burden those actions replace. Several scenes prove only a calculator or sample workflow, not the AI capability their product names might suggest.

### Cited Findings
Local files are primary evidence of this implementation, not evidence of customer deployments:
- The 33 scripts and capture actions are in [films.json](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json). The published narrative catalogue is [catalog.js](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/outputs/innate-vault/src/films/catalog.js).
- **Self-Bill:** the present script explains editing the first lift price and recalculating totals. It never explicitly establishes the operational problem of relating agreed work to stage values. Its final line promises a consistent matrix but gives little reason for a non-specialist to care. Capture actions contain only one price edit; two subsequent scenes have no new action. [Film source](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json)
- **Drawing-to-Quote:** “turning measurements into a commercial view” assumes the audience already understands the estimator’s job. The shown sequence carries proposed dimensions into a calculator and changes length. It does not establish reliable arbitrary drawing interpretation or a completed construction estimate. [Film source](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json)
- **Meeting Actions:** “open an action”, “set the missing deadline”, “open the editable client follow-up” describes operation rather than why follow-up work fragments. The useful story is extracting commitments into a reviewed task register and coherent client message. [Film source](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json)
- **Invoice:** the bank-detail exception supplies a concrete moment with stakes, but the film is a queue inspection and escalation sequence. It does not establish automated payment, fraud detection or a finance-system integration. [Film source](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json)
- **Client Intelligence:** the local implementation extracts the currency amount, blue dial and steel material with regular expressions; filters a fixed three-item stock array; prepares a template follow-up. **Sales Performance:** four regular-expression rules locate evidence in a transcript. These are functioning local demonstrations, not evidence of an AI service understanding arbitrary conversations. [apps.js, client at lines 12–14 and sales at line 17](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/outputs/innate-vault/src/experiences/apps.js:12)

### Inferences
- Replace procedural narration (“click”, “open”, “change the number”) with cause and effect (“the commitment becomes a task with an owner and deadline”). Show the click briefly only if it proves the transition.
- Synthetic does not mean visually weak. Use one believable persona, input and decision. It does mean no invented client names presented as customers, fabricated quotations, false deployment history, or metrics presented as measured results.
- Separate **observed output** (“the reviewed actions appear in the task register”) from **intended benefit** (“designed to reduce the work of reconstructing follow-up”). A stronger claim needs stronger evidence.
- Do not add a blanket “AI” sentence to every film. If original product evidence confirms extraction/summarisation/generation, explain input, operation and review: “AI proposes the commitments from the meeting; the adviser confirms responsibility and timing.” If not confirmed, describe the workflow shown.
- Avoid “compliant”, “error-free”, “understands every conversation”, “prevents fraud”, “automatically syncs to your CRM”, “saves X hours”, unless specifically established by the source implementation and appropriate evidence.

### Gaps
- Which originals contain genuine model-backed extraction, reasoning or generation, versus rules and interface simulations?
- Which integrations are working, which are illustrative, and where do outputs actually persist?
- Which pain statements reflect observed prospect/client feedback? Until answered, the proposed pain openings are editorial hypotheses to approve, not research findings about Innate customers.
- Which examples embody distinctive expertise a decision-maker could not get from an ordinary CRM, spreadsheet or generic assistant?

## How should the films and scripts be rebuilt?

### Takeaway
Recommend approximately 60–90 seconds for a single coherent story, permitting up to 120 seconds only when needed to show a consequential decision or handoff. This is an editorial recommendation, not a scientifically established optimum. Approve one complete script and storyboard before generating further voiceover.

### Cited Findings
- The reference player is 2:10, so the requested reference does not support treating 30–60 seconds as a hard constraint. [Reference page](https://www.intelliflo.com/software/artificial-intelligence/)
- Wistia's guidance makes duration dependent on purpose and audience; it does not prescribe one universal optimum. [Length guidance](https://wistia.com/blog/optimal-video-length)
- The current Innate film sources supply concrete inputs, review steps and outputs, but not independently verified historical business outcomes. [Film source](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/work/product-films/films.json)

### Inferences
**Recommended 75–90-second editorial structure**

| Beat | Approximate time | Narrative job | Visual evidence |
|---|---:|---|---|
| Problem | 0–15s | Name one person, recurring burden and consequence | The actual unstructured input or unresolved work, highlighted sparingly |
| Solution promise | 15–25s | Say in one sentence what the tool changes | Input and desired output visible together |
| Demonstration | 25–60s | Follow the same record through 2–3 meaningful transformations | Source detail -> proposed structure -> reviewed output; show exact matching values |
| Impact | 60–80s | Resolve the opening pain with an observable result | Completed output, ownership and remaining exception if relevant |
| Next step | Last 5–10s | Invite a relevant conversation or deeper look | Quiet branded end frame; one next action |

Working narration allowance: roughly 130–180 words for 60–90 seconds, then time the actual selected voice with deliberate pauses. If a 30–60-second cut is required, target roughly 65–110 words and one transformation, not a sped-up feature tour. Up to 120 seconds may support roughly 200–240 words, but do not fill the time for its own sake. These are drafting allowances; actual delivery governs duration.

**Shot and sync rules**
- A claim must coincide with its proof. When narration says a budget is extracted, show that budget in the source and proposed field at that moment.
- Maintain a single scenario through the whole film. No changing names, numbers or source documents between shots.
- Use a wide orientation shot, then crop to the relevant input/action/result. Full-screen dashboards are context, not the core explanation.
- Show meaningful state changes rather than slow pans across static screenshots. Allow a reading beat on the final output.
- Use captions for speech and short emphasis labels for the visual story. Do not layer a paragraph of subtitles over a paragraph of identical headline text.
- Include review as part of the product's mechanism, not as a defensive disclaimer at every step.
- Design silent comprehension too: a viewer should follow input -> transformation -> output without sound.
- End with one outcome. Brand montage or generic “more time for what matters” should not substitute for the actual result.

**Provisional script A: Meeting Actions and Client Follow-up**

Problem: “The client meeting is over. The follow-up work is not. Commitments are still buried in the conversation, and an action without an owner or deadline is difficult to follow through.”

Solution: “Innate Meeting Actions brings the proposed tasks beside the meeting transcript. The adviser can check each commitment against what was actually said, confirm who owns it and fill in the missing deadline.”

Demonstration: “Here, the client needs to confirm an education-funding amount. Give that action a due date, review it, then bring the accepted tasks and outstanding questions into one editable follow-up.”

Impact: “The meeting now has a practical next step: a task register for the team and a clear message for the client. The commitments are visible, and the responsibilities are explicit.”

Shot plan: highlight funding commitment in source; reveal proposed action and missing date; complete review; show the same action in follow-up/task output. No AI wording until the extraction mechanism is verified. Pain premise requires user validation. No claim of actual time saved.

**Provisional script B: Invoice Operations**

Problem: “An invoice is ready for review, but the supplier's bank details have changed. The finance team needs to understand that exception before deciding what happens next.”

Solution: “Innate Invoice Operations brings the flagged issue, amount and source invoice into one review workflow.”

Demonstration: “Open the bank-detail exception and compare the invoice with the supporting record. If the change is still unresolved, escalate it for independent verification. The queue records that decision, so the next reviewer can see what needs attention.”

Impact: “The result is a specific issue with a clear handoff, instead of an unexplained item left in the queue. The team can concentrate its review on the unresolved change.”

Shot plan: flagged bank detail -> source/supporting record comparison -> escalation -> changed queue status. Do not claim payment blocking, fraud prevention or automatic bank verification. Generic ‘AI invoice agent’ language would exceed this evidence.

**Provisional script C: Client Intelligence, a rebuild candidate rather than an immediate flagship**

The parallel tool audit identifies Client Intelligence as requiring rebuilding. This rewrite is a narrative exercise grounded in the limited local workflow, not a recommendation to publish it now or imply full original-product capability. The stronger immediate audit candidates are Proposal/Quote, Drawing-to-Quote, Annual Review, Listing Inbox and Invoice. See [tool evidence audit](/Users/max/Documents/Codex/2026-09-28/https-drive-google-com-drive-folders/research_notes/Innate%20vault%20strategy%20and%20storytelling/tool_evidence_audit.md).

Problem: “A returning client should not have to repeat what they are looking for. But preferences left in conversation notes still need to become something the team can use.”

Solution: “Innate Client Intelligence brings those notes, reviewed preferences and the next follow-up together.”

Demonstration: “Amelia is looking for a steel watch with a blue dial, within a twelve-thousand-pound budget. The details appear as proposed profile updates. Once reviewed, they narrow the available pieces to a matching option. A follow-up draft carries the chosen piece and price into a message the team can refine.”

Impact: “The result is a reviewed preference record and a relevant message ready for the next conversation. The client’s request becomes a concrete next step.”

Shot plan: source note highlighting three preferences -> same values in review -> qualifying stock vs excluded option -> edited follow-up plus timeline entry. Do not imply cross-team/cloud CRM persistence, actual live inventory, universal free-text understanding or a completed customer purchase. Local source currently implements regex and templates, so this script deliberately does not call it AI.

These are provisional directions pending the tool audit, not approved finished copy. Their purpose is to demonstrate the shift in logic. The selected shortlist and verified product capability should determine final wording.

**Production sequence recommendation**
1. Choose the strongest representative workflow after portfolio review.
2. Write a one-page claim ledger: pain hypothesis, supported mechanism, exact output, permissible impact, evidence gap.
3. Approve script and matched storyboard for that film.
4. Produce one finished pilot with the existing chosen voice, then assess whether a first-time viewer can name the problem, operation and outcome.
5. Only then apply the pattern to the selected portfolio. Do not regenerate all 33 before curation.

### Gaps
- Confirmed direction: organise by business problem. Support discovery of custom workflows, delivery credibility and specific-tool enquiries with one contextual CTA per film, carrying the product/workflow into the enquiry. Exact CTA wording still follows the selected example and final tool audit.
- Which pain is commercially strongest for each shortlisted tool? User confirmation needed before final voice generation.
- What original evidence can substantiate an AI mechanism beyond the local reconstruction?
- Are 60–90-second narratives sufficient after the first storyboard, or does a specific tool require a longer proof sequence? Decide per film, not by adding filler.
