# Product depth and film readiness

Working recommendation, 29 September 2026. Not an implementation record or an approved specification. Live Version 1 remains unchanged. The local Version 2 presentation was rejected and must not be republished inadvertently.

## Standard

Each product needs one complete journey: a recognisable business situation, evidence entering the tool, a consequential decision, and a useful resulting work product. Changing the input or decision must change the relevant output. A completed status badge alone is insufficient.

Recovered front ends do not establish the limits of the original products. Seek originals before rebuilding missing capabilities. Distinguish observed functions from the proposed journeys below. Do not infer connected integrations from related screens.

Names remain intact. The working collection has 13 entries. Sales Performance incorporates Call Capture and Broker Coach. Removed featured entries remain preserved as assets. No manufactured client attribution or measured outcomes.

## Proposed acceptance journeys

| Product | Proposed situation and complete outcome | Required demonstration before filming |
| --- | --- | --- |
| Client Intelligence System | A returning client's new request updates a relationship history, produces relevant recommendations, and equips the next colleague to continue the conversation. | Combine prior context and new preferences; retain exclusions and deadlines; explain matches and rejected alternatives; carry reviewed details into an editable follow-up. Original app needed: recovered version only extracts a few keywords and searches three pieces. |
| Sales Performance Dashboard | A manager identifies a recurring weakness, examines actual calls, and assigns a specific coaching intervention while sales commitments become accountable follow-ups. | A coherent multi-call, multi-person dataset; assessment linked to transcript evidence; meaningful differences between calls; call commitments and coaching actions kept distinct; team view derived from underlying records. Broad sales versus broker-first positioning awaits user guidance. |
| Proposal and Quote Agent | A new brief becomes a scoped, priced proposal; a commercial revision exposes its effect on margin and approval. | Scope, costs, discount, margin, approval and final proposal agree. Show a materially different commercial decision, not simply a document export. Verify local approval fixes against the intended release. |
| Invoice Operations Agent | A finance team processes ordinary invoices while an exceptional bank-detail change requires review. | Show routine and exceptional paths; source evidence explains the hold; a review decision updates the queue and resulting handoff. Do not portray escalation as confirmed fraud prevention or a real payment. |
| Reporting and Reconciliation Agent | A reporting discrepancy is traced to its source, resolved or held, and reflected in the management pack. | Resolution changes the affected reconciliation and report. Unresolved differences remain explicit. Current recovered status updates do not establish this causal flow. |
| Drawing-to-Quote Engine | An estimator translates a drawing into a checked takeoff and priced quotation, then handles a measurement revision. | Drawing, dimensions, quantities and price stay connected. Show the revision propagating into the final output. Original extraction evidence is needed before depicting arbitrary document processing. |
| Crew Readiness & Labour Planner | A planner fills a job with a suitable available crew and handles a conflict. | Date, capacity and required qualifications materially affect eligibility; explain exclusions; confirm an assignment and reflect it in availability. The recovered ranking alone does not establish this full workflow. |
| Applications & Payment Control | Completed work is supported, applied for, certified and tracked through outstanding payment. | One consistent work record links evidence to amounts at each stage; disputed or uncertified amounts remain distinct; a changed decision changes the balances and next action. Existing next-action notes alone are insufficient. |
| Availability & Listing Inbox | A new property update arrives with both supported changes and missing information. | Compare source and existing record; apply supported changes; hold ambiguous fields; produce a precise clarification request. The resulting listing reflects the decisions. |
| Property Matcher & Shortlist Builder | A client's brief becomes a reasoned shortlist, then changes when a requirement changes. | Criteria genuinely affect candidates; explain trade-offs and exclusions; unknown availability is not treated as confirmed; exported shortlist matches current criteria, selection and commentary. |
| Annual Review Pack Studio | An adviser prepares a review from records of different dates and identifies missing evidence before the meeting. | Sources feed the financial position and pack; excluding a source has a visible consequence; incomplete liabilities cannot produce a falsely complete net-worth figure; notes and open questions reach the pack. |
| Retail Market Intelligence | A buyer investigates an assortment or pricing question and produces a source-supported comparison for a decision. | A specific question drives filters and comparison; equivalent products are compared meaningfully; dates and source links remain available; the output answers the question. A searchable catalogue alone is not the complete story. |
| Fact Find Writer | Scattered client evidence becomes a structured proposed record, discrepancies receive adviser review, and approved changes proceed to Intelliflo. | Demonstrate mixed sources, current-versus-proposed fields, a discrepancy, field-level decisions and a controlled write result. Live intake and repository documentation have been inspected; a fresh end-to-end run has not been performed. Use a suitable non-production example for that validation. |

## Film production gate

1. Confirm the product's original scope and inspect available originals.
2. Make the chosen journey coherent and verify both the successful path and one meaningful exception or changed input.
3. Write narration against that journey: establish the problem, reveal the mechanism, demonstrate the operational consequence. These are narrative beats, not three title slides.
4. Plan shots that show changing product state, evidence and outputs. Use readable close framing and purposeful transitions. Avoid perpetual zooms on a static screen.
5. Produce one complete film for review before repeating the production approach across the collection. Select the pilot after the broader products' original sources are assessed; Fact Find Writer provides a useful depth benchmark without becoming the sole industry-led flagship.

No new narration or mass film rendering until the product journey and pilot treatment are settled. Continue with Kristen unless the user changes the voice preference.

## Outstanding user context

- Original apps, repositories or recordings for the other shortlisted tools, especially Client Intelligence, Sales Performance and Reporting and Reconciliation.
- Whether the combined Sales Performance demonstration targets general sales teams or property brokers first.
- Whether visitors should explore curated working examples, process their own inputs, or watch films before requesting a private demonstration. This changes implementation scope substantially.

## Evidence references

- `research_notes/Innate vault strategy and storytelling/tool_evidence_audit.md`: recovered source audit; its earlier shortlist and all-synthetic assumption have been superseded by subsequent user guidance.
- `outputs/innate-vault/src/experiences/apps.js`: inspected again for Client Intelligence and Sales Performance limitations.
- Original Fact Find Writer: https://github.com/maxbergman01-cmd/innate-rfp and https://rfp-partners-workspace.onrender.com/.
- Fact Find Writer review specification: https://github.com/maxbergman01-cmd/innate-rfp/blob/main/docs/04-review.md. Repository documentation is supporting evidence, not a substitute for runtime verification.
