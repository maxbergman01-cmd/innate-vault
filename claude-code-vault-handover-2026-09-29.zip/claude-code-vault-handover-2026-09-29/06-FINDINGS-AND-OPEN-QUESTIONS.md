# Findings, contradictions and missing context

## Freshly verified in the latest pass

Published Proposal and Quote, Loxley Foods example:
- 12% discount: £44,176 total, displayed 30% margin. Margin warning names James Attwood; send control names Elena Wray.
- Change to 5%: £47,690 total, displayed 35% margin. Price and preview update correctly.
- Approval state remains awaiting approval and incorrectly says 5% exceeds the 10% delegation.
- No approval or send was executed. Evidence screenshot and validation note are included.

Local source contains an earlier discount/approver correction, but this pass did not runtime-test that correction. It sits inside rejected Version 2. Do not roll out that version wholesale to recover one fix.

Pack-creation checks: local HEAD fdd7d9d; application working tree clean; Node 20.11.1; all 17 tests passed. These tests do not establish acceptance of the current product/film direction.

## Important source-supported or historical findings to independently verify

- Client Intelligence: regex extraction of budget/blue/steel, three stock items and a templated follow-up in the reconstruction. Original catalogue describes customer memory across the company, potentially much broader.
- Sales Performance: one editable transcript, four keyword checks and a coaching export. Not demonstrated team-wide analysis. Broker Coach is a separate fixture workflow, not an implemented integrated dashboard.
- Reporting: confirmation changes exception status; sendReport changes a boolean. Previously inspected sources did not establish causal reconciliation changes to management metrics.
- Crew: fit ranking exists; full-member qualification eligibility and allocation persistence are not established.
- Payments: recorded stages and action notes exist; decisions driving the full evidence-to-cash sequence are not established.
- Matcher: unknown availability can pass the observed filter; preselected properties and commentary may not follow changed criteria automatically.
- Retail: captured public records, historically 585 Home / 651 Beauty. Do not infer a current crawl, live trend detection or fresh synthesis. Recheck dataset counts/date and comparison outputs.
- Annual: source exclusion and notes affect pack; missing mortgage blocks a complete net-worth value. Historical runtime observations, source logic and tests support parts of this behaviour; repeat on the version being assessed.
- Listing: supported accepted fields update the record, ambiguous/stale ones remain held, clarification draft available. Repeat on the selected scenario/version.
- Quote: reviewed dimensions change quantities/pricing; arbitrary visitor upload extraction was not supported by recovered source.
- Invoice: historical escalation changed the local exception queue; page reload reset state. Both payables and collections exist in the interface.

## Fact Find Writer evidence boundary

Original live intake and private repository were inspected. Supported intake types include meeting transcript, fact-find document, spreadsheet, photo/scan, ID verification and voice note, with existing/new-client paths. Review documentation describes proposed versus current fields, accept/edit/reject/pending decisions and a confirmation before writeback. Repository history describes validation, partial writes and audit issues. These are UI/source/documentation observations, not a fresh successful extraction-and-writeback run.

Do not turn commit descriptions into proof every integration scenario works. Some historical docs are prototype plans or dated gap lists. Compare documents to current implementation and safe observed behaviour. Separate Action Tracker from Fact Find Writer.

## Unresolved questions, not assumptions

These earlier questions received no recorded answers. Do not say the user approved them:
1. Client Intelligence's central value: team customer memory, sales opportunity/product matching, or capture/CRM update? Existing catalogue suggests memory; original product evidence still needed.
2. Sales Performance: cross-industry sales teams or broker-first scenario?
3. Retail: assortment/product development, pricing/positioning or launch monitoring as the primary decision?
4. Original apps/repos/recordings for other tools, especially Client Intelligence, Sales Performance and Reporting. Are Proposal/Invoice/Reporting based on specific original workflows, or should a later phase design them?
5. Visitor experience after film: curated editable example, visitor-owned inputs, or private demonstration?
6. Product Operating Backbone: original scope and significance. Its selection is now open under the latest instruction; no further permission is needed simply to reassess it.
7. Per-tool real-client provenance, genuine AI mechanisms, permitted evidence and measurable outcomes remain incompletely documented.
8. Full industry suites versus strongest standalone tools remains a strategic question to evaluate.

Prioritise questions that change a decision. Ask in small groups with the consequence explained. Do not make Max answer a34-tool questionnaire before doing available inspection. “Continue” does not answer an outstanding multiple-choice question.

## Historical documents that can mislead

IMPLEMENTATION-STATUS.md has a controlling rollback notice at the top, followed by old “Version 2 is live” and publish instructions. README is a chronological log with contradictory counts and superseded voices. Research notes include earlier all-synthetic assumptions, smaller shortlists and benefit-first naming. Film metadata saying ready means a historical asset existed, not that Max approved its quality.
