# Required audit deliverables

Write new audit output separately from application source, for example a dated folder under the workspace's reports directory. Do not overwrite this handover or earlier evidence.

## 1. Executive recommendation

Lead with the proposed collection and why. Explain the strongest examples, weakest links, overlaps, pilot choice, presentation recommendation and decisions needed. Do not simply repeat this handover's recommendations.

## 2. Complete tool matrix and supporting records

One row for each of the 34 known entries, plus any additional tools established during reconciliation. Include prior disposition, proposed disposition, original versus recovered capability, buyer/job, AI mechanism evidence, normal and exception test status, useful output, defects, missing evidence, effort/dependencies, film readiness and evidence links.

Every entry receives a decision or explicit unresolved status. Every recommended merge names its members and actual integration/packaging requirements. Explain every proposed reversal of a prior removal or keep decision. Do not delete anything.

## 3. Film and content audit

Catalogue all 33 legacy films, the original Client Intelligence pilot and five rejected story variants, reconciling actual files and duplication. Provide version, viewing coverage, timestamped findings, claim issues, narration/audio/caption quality and concrete recommendations. An unplayed film must not be reported as reviewed.

For the recommended collection, provide revised narrative outlines and shot sequences grounded in the tool audit. Label unverified scenes and missing capability. Explain the best production pilot, proposed duration, required footage, voice/audio treatment and acceptance test before scaling production.

## 4. Portfolio and visitor sequencing

Provide the proposed 10-15-example order, first-screen selection, suite/standalone rationale, filters and film/tool/enquiry path. Preserve product names unless Max explicitly changes that requirement. Separate changes to films from changes to page content.

## 5. Prioritised implementation backlog, not implementation

For each item: problem, affected version/files/tool, proposed fix, business/film impact, dependency, acceptance criteria and priority. Distinguish source recovery, functionality repair, product expansion, claims/script work, design/edit production and release operations. Estimates must state uncertainty and assumptions.

## 6. Evidence and scope record

Record environments, versions, dates, commands, test results, screens/exports and inaccessible sources. Distinguish new observations from copied historical evidence. Never store secrets. Include unresolved questions and blocked actions with exact prerequisites.

## Completion checks

- All 34 known tool entries accounted for, plus any additional tools found during reconciliation; duplicates and original/reconstruction distinctions explicit.
- Every old removal, merge and keep decision assessed afresh.
- Every claimed test has evidence and a named version; no status-only proof of an external action.
- All relevant films accounted for with honest viewing coverage.
- Content and production recommendations explain how a first-time viewer understands the product.
- Proposed shortlist and sequencing respect the latest preferences or identify a conscious recommended departure.
- No product changes, publication, paid generation or client-data writes performed.
- Missing access or context remains clearly unresolved, not guessed.

The audit can be delivered with explicit blockers, but must not be called fully validated if tool journeys or films remain uninspected.
