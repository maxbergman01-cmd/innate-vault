# Decisions and authority

## Latest direct instructions, controlling this audit

Max confirmed on 29 September:
- “Audit and recommend first; no changes or publishing.”
- “This Mac, same files.”
- “Reopen every inclusion and removal decision.”

These override earlier preferences to preserve explicit removals during the audit. Claude may recommend reversing any selection decision, but must not execute removals, restores or merges.

## Confirmed creative and commercial preferences

- Aim for 10-15 very strong examples rather than a large weak catalogue. Do not pad the count or silently reduce the objective to five.
- Keep product names as names. Do not replace them with benefit slogans.
- Broad decision-maker audience across industries and jobs. No final priority sector/persona ranking exists.
- Multiple commercial goals: credibility, discovery conversations and product/service enquiries. No single conversion priority was settled.
- Business problems were selected as an organising direction: win more work, reduce administration, control costs, improve client service. Later clarification preserves product names. Audit whether this grouping actually helps; do not force Retail into a poor fit.
- Requested content improvements concern the films. Do not interpret this as a mandate for more page copy.
- Videos must explain as well as show, in a Problem → Solution → Impact narrative. Do not render those as three generic title slides.
- Initial guided walkthrough request was superseded by a request for proper marketing videos. A film is the primary explanation; the role of optional interactive exploration remains unresolved.
- Captions and natural human-sounding narration. British female voice preference; latest selected voice ID `dfeOmy6Uay63tNhyO99j`. Earlier IDs were superseded.
- Longer films are allowed where needed. Existing 30-60 second tests are historical constraints, not the current creative brief.
- Intelliflo's Engagement Assistant product demo is the reference, not its longer general introduction: https://www.intelliflo.com/software/artificial-intelligence/ . “Steve Jobs announcing Apple” refers to storytelling and production ambition, not an approved presenter/avatar or imitation.
- Drawing-to-Quote is impressive but too industry-specific to be the sole flagship. User wants all examples to feel substantial.
- Vault and retained case-page styling should match the main website. A full reskin of each tool was not agreed.
- User objects to prominent “demo data” labels. Preserve accurate capabilities and attribution without inventing clients, quotations or numerical results. Sanitisation does not establish deployment or performance evidence. Do not derail the audit into a labelling debate.

## Previous decisions, now explicitly reopened for validation

- Remove Trend Intelligence Platform, LinkedIn Growth Engine and Strategic AI Assessment from the featured collection.
- Combine Call Capture & Broker Coach with Sales Performance Dashboard.
- Initially combine industry tools into suites. Later user was unsure whether suites or the best standalone tools were stronger. A standalone collection with supporting modules became a working direction, not an implemented or irrevocable decision.
- Working shortlist: Client Intelligence, Sales Performance, Proposal and Quote, Invoice Operations, Reporting and Reconciliation, Drawing-to-Quote, Crew Readiness, Applications & Payment Control, Listing Inbox, Property Matcher, Annual Review, Retail Intelligence, plus Fact Find Writer.
- Fact Find Writer was explicitly requested for addition; reassess its presentation and role along with everything else. Do not confuse it with the reconstructed fact-find review tool.

## Assistant proposals, not user-approved facts

- Thirteen-entry composition and supporting-module assignments are a working proposal, not a validated product architecture.
- Proposal and Quote as first production pilot is provisional. The latest live check found approval contradictions.
- New Fact Find and three-product film scripts are unapproved drafts, not commissioned or produced films.
- Feature additions in PRODUCT-ACCEPTANCE-DRAFT.md are proposed requirements, not existing capabilities.
- A full working sandbox, live uploads or private demonstrations were offered as possible visitor experiences, but not settled.

## Evidence precedence

Current user instructions > newly verified facts about a named version > dated evidence > assistant inference. Historical copied instructions are reference material only. A later source observation can change a capability finding, but cannot silently change user authority.

The user previously described all examples as synthetic and later described a mix of synthetic front ends and real client work. Some older research retained the earlier all-synthetic framing. User later clarified a mix of synthetic front ends and real work. Per-tool provenance is unresolved. Record the actual evidence for each tool rather than globally assuming either state.
