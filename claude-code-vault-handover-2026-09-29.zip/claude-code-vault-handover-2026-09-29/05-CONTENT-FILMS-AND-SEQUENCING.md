# Content, films, sequencing and presentation audit

## Inspect actual assets

Use the inventory's film metadata to locate every historical film. Review the original Client Intelligence pilot and the five rejected *-story.mp4 films as separate versions. Source scripts, duration metadata and decodable media are not substitutes for watching and listening. Record which films were watched fully, which were sampled and which could not be played. Mark non-reviewed assets as outstanding.

Check the published viewer separately from local media: card destinations, video version served, title, poster, playback, audio, captions, pause/seek/replay/fullscreen, mobile view, fallback behaviour, and the route into the tool or enquiry. Do not assume a film file exists live because it exists locally.

## Narrative and claim review

For each film identify the user, problem, consequence, tool intervention, AI role if supported, human decision and resulting impact. Ask whether a first-time viewer could explain the tool after one watch. Flag narration that merely lists clicks, generic benefits, unexplained domain jargon, invented performance claims or capabilities not demonstrated.

Problem → Solution → Impact should form one causal story. Test whether the final output resolves the opening pain. No arbitrary duration cap: recommend length based on story and readable action. Do not stretch a simple workflow or cram several products into one minute.

Keep product names. Audit whether essential page context is sufficient, but do not turn the user's request for film content into long Problem/Solution/Impact page copy. Assess the distinction between a product portfolio and client evidence without making unnecessary changes to public labelling.

## Production-quality review

Use timestamped observations, not “make it premium”:
- What is moving: real product state, meaningful transition, or just a still image zoom?
- Can the viewer read the relevant input and see its relationship to the output?
- Are shots composed and paced around the explanation, or are whole dashboards shrunk into decoration?
- Is there a strong opening, a substantial reveal and a useful concluding state?
- Are narration, product action and captions synchronised?
- Is the voice intelligible and natural? Check source quality, artefacts, clipping, muffling, unnatural emphasis, abrupt edits and music masking speech.
- Do typography, spacing, imagery, transitions and sound feel consistent with Innate and the main site?
- Are captions accurate, readable and correctly timed? Is important content still understandable muted?
- Does the tool behave continuously across shots? Reject impossible state changes hidden by edits.
- Do visible claims, invented scores or client-like details imply evidence that is missing?

For each defect state its effect on comprehension/credibility and the specific remedy. Distinguish script changes, missing product behaviour, footage to capture, edit changes and audio changes.

## Reference research and limits

The chosen Intelliflo Engagement Assistant video was previously identified as approximately 2:10, versus a roughly 4:50 introduction. Only a frame around 0:45 and page text were inspected in the earlier research, not the complete film/audio. Claude must locate and review the correct current video before drawing detailed production conclusions. URL: https://www.intelliflo.com/software/artificial-intelligence/

Prior benchmark notes include Faculty, Baringa, Thoughtworks, QuantumBlack, BCG, Satalia and HatchWorks. Their observations were mostly page-text structure, not full interaction/mobile audits or conversion studies. Revisit relevant current examples if using them to justify a recommendation. Do not copy their outcome figures or assume their presentation proves conversion effectiveness.

Several older benchmark recommendations conflict with later user instructions: benefit-first titles, a five-to-eight-tool public selection and expanded case-page copy are not current requirements.

## Sequence at three levels

1. Portfolio sequence: recommend a first-screen selection and full 10-15-example order. Explain breadth versus sector depth, distinctiveness and what each successive entry adds. Do not default to Drawing-to-Quote as sole flagship. Consider repetition of finance/adviser review interfaces.
2. Film sequence: propose one narrative and concrete shot order per recommended featured example, grounded in verified capability. Include missing footage, unresolved claims and approximate natural duration. An internal storyboard is allowed; rendering new films is outside this audit.
3. Visitor sequence: assess card → film → optional tool exploration → relevant enquiry. The role of public editable examples versus own-data uploads versus private demos remains unresolved. Recommend a path with explicit assumptions for Max to decide.

## Drafts to critique, not automatically adopt

The pack includes FACT-FIND-FILM-TREATMENT.md and THREE-PRODUCT-FILM-DRAFTS.md. Neither was approved or produced. Proposal and Quote as pilot is a provisional assistant recommendation, weakened by fresh live approval findings. Recommend the best pilot independently, and explain what it would prove about both product substance and production quality.

Do not generate ElevenLabs audio, spend credits, capture client data or render/publish films during this audit.
