# Validate every tool

## Audit each entry, including proposed removals

Start by reconciling the 34-row inventory with the original catalogue, industry collections and supplied handover references. If additional distinct tools are found, add them with provenance and explain the count change. Do not silently omit an entry or treat an adjacent repository module as an approved vault addition.

Treat each product as a business workflow, not just a set of screens. Record intended user, triggering situation, painful current process, consequence, inputs, mechanism, human decisions, useful outputs and downstream destination. Unknown purpose is a question, not permission to invent a use case.

Separate four questions: what the original product can do; what this recovered version can do; what the film actually shows; what the page/script claims. They may have different answers.

## Required checks for each available tool

1. Open the exact entry route and record version, date, browser and initial state. Verify the card/film/tool link chain and reload/deep links. Distinguish backend failures from missing local route fallbacks.
2. Complete one meaningful normal journey. Inspect the output itself. A toast or green tick is not proof of successful processing, sending, writing or exporting.
3. Change an input meaningfully. Check that all affected figures, records, explanations and outputs change consistently. Stale result invalidation matters.
4. Exercise an exception: missing information, ambiguity, conflicting source, rejected field, empty result, invalid value or unmet prerequisite. Do not run destructive or consequential production actions.
5. Inspect save/revisit/reload behaviour. Explicitly label session-only state. Do not silently demand production persistence if a curated example is the agreed purpose.
6. Inspect downloadable output where safe: current input, decisions, order, figures, notes and unresolved items should survive. If a download is unavailable, record the limitation.
7. Trace the critical data path in code where source is available. Distinguish hardcoded fixture, template, regex, rules/calculation, actual inference, external retrieval and integration. Do not call arithmetic AI or a changing loading label model processing.
8. Inspect source attribution and human control. Does the evidence support the proposed value? Are missing values held? Can a person see and correct the result? Do approval rules actually govern the action?
9. Check usable desktop/mobile layout, readable labels, keyboard access to main controls, empty/error/loading states and sensible recovery. Check network and console failures where available. This is scoped functional review, not a penetration test.
10. Compare these observations with page claims and film narration. Mark contradictions explicitly.

For integrations, distinguish configuration/code path, fixture simulation, successful request, destination readback and verified business result. Never infer success from a 2xx alone. On original live systems, stop before client-record changes, upload of private materials, external sends or paid inference unless a safe environment and specific permission exist. Report not tested and the exact prerequisite.

## Evidence format

Per finding: tool ID; source/version/URL; scenario; steps; expected result and basis; observed result; supporting screenshot or output; severity; confidence; proposed correction; boundary of test. Keep sensitive material out of screenshots and handover files. Never save credentials.

Statuses: verified in this audit / observed previously / source-supported only / proposed / unavailable / unresolved. Do not present all as equivalent.

## Evaluate selection independently

For each tool recommend KEEP, MERGE, DEVELOP BEFORE FEATURING, RESERVE or REMOVE FROM FEATURED COLLECTION, with reasons. Removal is a recommendation about presentation, not deletion of source/assets.

Assess buyer relevance, complete transformation, distinctive capability, evidence, visual explainability, commercial usefulness, overlap and effort to reach the required standard. Use explained qualitative judgments, not invented precise scores. A weak reconstruction may conceal a strong original product.

For every proposed merger, describe: same user or handoff; shared data; one combined outcome; duplicated capability; missing connections; whether merger is navigation, film/story packaging or actual application integration. Do not call adjacent links one working suite.

Evaluate suite versus standalone presentation and the Call Capture/Sales merger afresh. Assess all historic removals, including Trend Intel, LinkedIn and Assessment. Keep the target of 10-15 in view without filling it with weak work. Explain any recommendation outside that range and seek a decision.

## Film-readiness gate

A tool is ready to film only when the chosen visible journey is coherent, evidence supports the script, output responds to the demonstrated decisions, significant exceptions are handled, and capture can be performed safely. Keep production readiness separate from general product quality and deployment readiness.
